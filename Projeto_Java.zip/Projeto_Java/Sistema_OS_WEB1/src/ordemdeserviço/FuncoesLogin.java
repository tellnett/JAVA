/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordemdeserviço;

import javax.swing.JOptionPane;

/**
 *
 * @author TELLNETT
 */
public class FuncoesLogin {

    public static TelaLoginArray sair() {
        System.exit(0);
        return null;
    }

    public static TelaLoginArray entrar() {
      /*Inicio de uma Array*/
        String tnome[] = {"wellington", "carlos", "mariana"};
        String tsenha[] = {"123", "333", "444"};
        String tperfil[] = {"admin", "user", "user"};
      /*Fim de uma Array*/
    
       /*variavel externa da tela de login com a classe publica*/
        String nome = TelaLoginArray.usuario.getText();
        String senha2 = TelaLoginArray.senha.getText();
      
        MenuPrincipal principal = new MenuPrincipal();

        try {//tratamento de erro
            for (int i = 0; i < 2; i++) { //contador para a array
                
                //Condição para saber se as informações digitada é a mesma que está cadastrar na array
                if ((tsenha[i].equals(senha2)) & (tnome[i].equals(nome)) & (tperfil[i].equals("admin"))) {
                                                                                                                            // comparação do perfil para saber se ele é administrativo
                    JOptionPane.showMessageDialog(null, "Bem Vindo ao Sistema " + nome);

                    principal.setVisible(true); //menu principal visivel
                  
                    MenuPrincipal.jMenuItem1.setEnabled(true);//
                    MenuPrincipal.jMenuItem2.setEnabled(true);//Deixando o botão do menu principal habilitado
                    MenuPrincipal.jMenuItem4.setEnabled(true);//
                        //Condição para saber se as informações digitada é a mesma que está cadastrar na array
                } else if ((tsenha[i].equals(senha2)) & (tnome[i].equals(nome)) & (tperfil[i].equals("user"))) {
                                                                                                                                     // comparação do perfil para saber se ele é Comum
                    JOptionPane.showMessageDialog(null, "Bem Vindo ao Sistema " + nome);

                    principal.setVisible(true); // Deixando a tela principal visivel para o usuario
                 

                }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Usuario e senha errado" + e);
        }
        return null;

    }
}
