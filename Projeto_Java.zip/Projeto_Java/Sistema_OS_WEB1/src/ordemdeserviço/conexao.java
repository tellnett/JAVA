package ordemdeserviço;

import java.sql.*;
import javax.swing.JOptionPane;

public class conexao {

    public static Connection conector() {

        java.sql.Connection conexao = null;
        String driver = "com.mysql.jdbc.Driver";

          String url = "jdbc:mysql://localhost:3306/sistemaos?Encoding=uft-8";
        String user = "root";
        String pass = "";

        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, pass);
            return conexao;
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);

            return null;
        }
    }
}
