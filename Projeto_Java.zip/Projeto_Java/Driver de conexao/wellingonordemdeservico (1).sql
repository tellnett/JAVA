-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 14/04/2021 às 14:12
-- Versão do servidor: 5.7.33-0ubuntu0.18.04.1
-- Versão do PHP: 7.2.24-0ubuntu0.18.04.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `wellingonordemdeservico`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `idade` varchar(3) NOT NULL,
  `nasc` varchar(11) NOT NULL,
  `sexo` varchar(49) DEFAULT NULL,
  `estadoci` varchar(50) DEFAULT NULL,
  `ende` varchar(129) NOT NULL,
  `tele` varchar(14) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rg` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nome`, `idade`, `nasc`, `sexo`, `estadoci`, `ende`, `tele`, `email`, `rg`) VALUES
(1, 'luucas', '12', '1312', 'Masculino', 'qweqwe', 'qweqwe', '12312', 'Solteiro', '213231'),
(2, 'qwe', '', '', 'Masculino', '', '', '', 'Solteiro', ''),
(3, 'qwe', '12', '123123', 'Masculino', '', '123', '', 'Solteiro', '123123');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbos`
--

CREATE TABLE `tbos` (
  `id_os` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tipo` varchar(50) NOT NULL,
  `situacao` varchar(40) NOT NULL,
  `equipamento` varchar(60) NOT NULL,
  `defeito` varchar(60) NOT NULL,
  `servico` varchar(50) NOT NULL,
  `tecnico` varchar(60) NOT NULL,
  `valor` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `tbos`
--

INSERT INTO `tbos` (`id_os`, `id_cliente`, `data`, `tipo`, `situacao`, `equipamento`, `defeito`, `servico`, `tecnico`, `valor`) VALUES
(7, 1, '2021-04-14 12:30:56', 'orçamento', 'Na bancada', 'notebook', 'qwe', 'qwe', 'qw', '0.00'),
(8, 1, '2021-04-14 12:31:14', 'orçamento', 'Na bancada', 'tablet', 'qwe', 'qwe', 'qw', '0.00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `senha`) VALUES
(1, 'wellington', '123123'),
(2, 'carlos', '12'),
(3, 'carlos', '1232'),
(4, 'roberto', '2123'),
(5, 'jorge', '2123');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Índices de tabela `tbos`
--
ALTER TABLE `tbos`
  ADD PRIMARY KEY (`id_os`),
  ADD KEY `tbos` (`id_cliente`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `tbos`
--
ALTER TABLE `tbos`
  MODIFY `id_os` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `tbos`
--
ALTER TABLE `tbos`
  ADD CONSTRAINT `tbos` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
